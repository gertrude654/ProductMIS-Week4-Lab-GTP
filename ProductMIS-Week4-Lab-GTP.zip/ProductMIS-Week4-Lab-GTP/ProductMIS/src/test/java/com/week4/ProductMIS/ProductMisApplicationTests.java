package com.week4.ProductMIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMisApplicationTests {

	@Test
	void contextLoads() {
	}

}
